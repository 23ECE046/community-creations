wiseconnect3_sdk_3.4.2/components/device/silabs/si91x/wireless/ahb_interface/src/rsi_hal_mcu_m4_rom.o: \
 C:/Users/Bharanidharan\ R/SimplicityStudio/SDKs/simplicity_sdk/extension/wiseconnect/components/device/silabs/si91x/wireless/ahb_interface/src/rsi_hal_mcu_m4_rom.c \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_types.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_constants.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_host_interface.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_status.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_slist.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_common.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_assert.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_constants.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_additional_status.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\ahb_interface\inc\sl_device.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_device.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\base_types.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\core_cm4.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_version.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_compiler.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_gcc.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\mpu_armv7.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\system_si91x.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_error.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\config\rsi_ccp_user_config.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_mvp.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\ahb_interface\inc\rsi_m4.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\ahb_interface\inc\rsi_pkt_mgmt.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\ahb_interface\inc\rsi_os.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_error.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_rsi_utility.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_constants.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_host_interface.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_types.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_constants.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_ieee802_types.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_ip_types.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_wifi_device.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_status.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_protocol_types.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_bit.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_utility.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_driver.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\firmware_upgrade\firmware_upgradation.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\rtos2\include\cmsis_os2.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\ahb_interface\inc\rsi_m4.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_ipmu.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_ccp_common.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\em_device.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_device.h \
 C:\Users\Bharanidharan\ R\SimplicityStudio\v5_workspaces\ble_hid_on_gatt_soc\config/RTE_Device_917.h \
 C:\Users\Bharanidharan\ R\SimplicityStudio\v5_workspaces\ble_hid_on_gatt_soc\config/pin_config.h
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_types.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_constants.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_host_interface.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_status.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_slist.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_common.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_assert.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_constants.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_additional_status.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\ahb_interface\inc\sl_device.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_device.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\base_types.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\core_cm4.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_version.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_compiler.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_gcc.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\mpu_armv7.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\system_si91x.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_error.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\config\rsi_ccp_user_config.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_mvp.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\ahb_interface\inc\rsi_m4.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\ahb_interface\inc\rsi_pkt_mgmt.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\ahb_interface\inc\rsi_os.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_error.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_rsi_utility.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_constants.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_host_interface.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_types.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_constants.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_ieee802_types.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_ip_types.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_wifi_device.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_status.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_protocol_types.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_bit.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_utility.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_driver.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\firmware_upgrade\firmware_upgradation.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\rtos2\include\cmsis_os2.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\ahb_interface\inc\rsi_m4.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_ipmu.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_ccp_common.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\em_device.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_device.h:
C:\Users\Bharanidharan\ R\SimplicityStudio\v5_workspaces\ble_hid_on_gatt_soc\config/RTE_Device_917.h:
C:\Users\Bharanidharan\ R\SimplicityStudio\v5_workspaces\ble_hid_on_gatt_soc\config/pin_config.h:
