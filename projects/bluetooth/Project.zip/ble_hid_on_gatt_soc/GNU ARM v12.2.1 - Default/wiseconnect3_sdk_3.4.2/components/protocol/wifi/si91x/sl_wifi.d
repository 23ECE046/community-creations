wiseconnect3_sdk_3.4.2/components/protocol/wifi/si91x/sl_wifi.o: \
 C:/Users/Bharanidharan\ R/SimplicityStudio/SDKs/simplicity_sdk/extension/wiseconnect/components/protocol/wifi/si91x/sl_wifi.c \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_wifi_device.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_status.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_types.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_constants.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_host_interface.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_status.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_slist.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_common.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_assert.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_protocol_types.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_ieee802_types.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_ip_types.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_constants.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_bit.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_types.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_constants.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_host_interface.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_driver.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\firmware_upgrade\firmware_upgradation.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_rsi_utility.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_constants.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_additional_status.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_utility.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\rtos2\include\cmsis_os2.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\socket\inc\sl_si91x_socket_utility.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\socket\inc\sl_si91x_socket_types.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\socket.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\uio.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\sys.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\netinet_in.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\netinet6_in6.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\select.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\socket\inc\sl_si91x_socket_constants.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\errno\inc\errno.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\ahb_interface\inc\rsi_wisemcu_hardware_setup.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_power_save.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_error.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\base_types.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_ccp_common.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\config\rsi_ccp_user_config.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\em_device.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_device.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\base_types.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\core_cm4.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_version.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_compiler.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_gcc.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\mpu_armv7.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\system_si91x.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_error.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_mvp.h \
 C:\Users\Bharanidharan\ R\SimplicityStudio\v5_workspaces\ble_hid_on_gatt_soc\config/RTE_Device_917.h \
 C:\Users\Bharanidharan\ R\SimplicityStudio\v5_workspaces\ble_hid_on_gatt_soc\config/pin_config.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_reg_spi.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_ipmu.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_system_config.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_ccp_common.h \
 c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\sl_net\inc\sl_net_si91x_integration_handler.h
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_wifi_device.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_status.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_types.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_constants.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_host_interface.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_status.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_slist.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_common.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_assert.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_protocol_types.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_ieee802_types.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_ip_types.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_constants.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\common\inc\sl_bit.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_types.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\protocol\wifi\inc\sl_wifi_constants.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_host_interface.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_si91x_driver.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\firmware_upgrade\firmware_upgradation.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\inc\sl_rsi_utility.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_constants.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_additional_status.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\common\inc\sl_utility.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\rtos2\include\cmsis_os2.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\socket\inc\sl_si91x_socket_utility.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\socket\inc\sl_si91x_socket_types.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\socket.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\uio.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\sys.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\netinet_in.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\netinet6_in6.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\service\bsd_socket\inc\select.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\socket\inc\sl_si91x_socket_constants.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\errno\inc\errno.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\ahb_interface\inc\rsi_wisemcu_hardware_setup.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_power_save.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_error.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\base_types.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_ccp_common.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\config\rsi_ccp_user_config.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\em_device.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_device.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\base_types.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\core_cm4.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_version.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_compiler.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\cmsis_gcc.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\platform\cmsis\core\include\mpu_armv7.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\system_si91x.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_error.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\si91x_mvp.h:
C:\Users\Bharanidharan\ R\SimplicityStudio\v5_workspaces\ble_hid_on_gatt_soc\config/RTE_Device_917.h:
C:\Users\Bharanidharan\ R\SimplicityStudio\v5_workspaces\ble_hid_on_gatt_soc\config/pin_config.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_reg_spi.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\drivers\systemlevel\inc\rsi_ipmu.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_system_config.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\mcu\core\chip\inc\rsi_ccp_common.h:
c:\users\bharanidharan\ r\simplicitystudio\sdks\simplicity_sdk\extension\wiseconnect\components\device\silabs\si91x\wireless\sl_net\inc\sl_net_si91x_integration_handler.h:
